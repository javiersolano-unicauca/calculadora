#ifndef LIBARREGLOS_H

#define LIBARREGLOS_H
// Autor: javiersolanop

/**
*   @brief Funcion para dimensionar el arreglo.
*
*    @param prmTamanio: recibe la cantidad de elementos que debe tener el arreglo.
*
*    @return El apuntador del arreglo.
**/
double* dimensionarArregloDeTipoDouble(int *prmTamanio);

/**
*    @brief Funcion para liberar el espacio en memoria del arreglo.
*
*    @param prmArreglo: recibe el apuntador del arreglo.
**/
void liberarArregloDeTipoDouble(double *prmArreglo);

/**
*    @brief Funcion para realizar el llenado de elementos.
*           Los recibe por consola.
*
*    @param prmArreglo: recibe el apuntador del arreglo.
*    @param prmTamanio: recibe el apuntador de la cantidad de elementos del arreglo.
**/
void llenarArregloDeTipoDouble(double *prmArreglo, int *prmTamanio);

/**
*    @brief Funcion para imprimir en consola los elementos del arreglo.
*
*    @param prmArreglo: recibe el apuntador del arreglo.    
*    @param prmTamanio: recibe el apuntador de la cantidad de elementos del arreglo.
*/
void imprimirArregloDeTipoDouble(double *prmArreglo, int *prmTamanio);

/**
*    @brief Funcion para imprimir en consola el resultado de las operaciones de los arreglos.
*
*    @param prmResultado: recibe el apuntador del resultado a imprimir.    
**/
void imprimirResultadoArreglo(double*prmResultado);

/**
*    @brief Funcion para recibir por consola los elementos del arreglo.
*           Despues imprime el arreglo obtenido.
**/
void recibirElementosDeArregloDeTipoDouble(double *prmArreglo, int *prmTamanio);

/**
*    @brief Funcion para realizar la operacion de suma de elementos.
*           Realiza el llenado por consola del arreglo y despues
*           la suma. Despues imprime el resultado.
*
*    @param prmTamanio: recibe el apuntador de la cantidad de elementos del arreglo.
**/
void sumarElementosDeArregloDeTipoDouble(int *prmTamanio);

/**
*    @brief Funcion para realizar la operacion de resta de elementos.
*           Realiza el llenado por consola del arreglo y despues
*           la resta. Despues imprime el resultado.
*   
*    @param prmTamanio: recibe el apuntador de la cantidad de elementos del arreglo.
**/
void restarElementosDeArregloDeTipoDouble(int *prmTamanio);

/**
*    @brief Funcion para realizar la operacion de multiplicacion de elementos.
*           Realiza el llenado por consola del arreglo y despues
*           la multiplicacion. Despues imprime el resultado.
*
*    @param prmTamanio: recibe el apuntador de la cantidad de elementos del arreglo.
**/
void multiplicarElementosDeArregloDeTipoDouble(int *prmTamanio);

/**
*    @brief Funcion para realizar la operacion de division de elementos.
*           Realiza el llenado por consola del arreglo y despues
*           la division. Despues imprime el resultado.
*
*    @param prmTamanio: recibe el apuntador de la cantidad de elementos del arreglo.
**/
void dividirElementosDeArregloDeTipoDouble(int *prmTamanio);

/**
*   @brief Funcion para ordenar los elementos, empleando el metodo 'Burbuja'.
*            Realiza el llenado por consola del arreglo y despues
*            el ordenamiento. Despues imprime el resultado. 
*
*    @param prmTamanio: recibe el apuntador de la cantidad de elementos del arreglo.
**/
void ordenarElementosDeArregloDeTipoDouble(int *prmTamanio);

/**
*   @brief Funcion para imprimir en consola los elementos de adelante hacia atras.
*           Realiza el llenado por consola del arreglo y despues
*            la reversion. Despues imprime el resultado.
*
*    @param prmTamanio: recibe el apuntador de la cantidad de elementos del arreglo. 
**/
void reversarElementosDeArregloDeTipoDouble(int *prmTamanio);

/**
*    @brief Funcion para multiplicar cada elemento por un escalar.
*            Realiza el llenado por consola del arreglo y despues
*           la multiplicacion. Despues imprime el resultado.    
*
*    @param prmTamanio: recibe el apuntador de la cantidad de elementos del arreglo.    
**/
void multiplicarElementosDeArregloDeTipoDoublePorEscalar(int *prmTamanio);
#endif
