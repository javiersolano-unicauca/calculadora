#ifndef LIBENTRADAYSALIDA_H

#define LIBENTRADAYSALIDA_H
// Autor: javiersolanop

/**
*	@brief Funcion para imprimir en consola un arreglo de tipo 'char'.
*
*	@param prmCadena: recibe el apuntador del arreglo.
**/
void imprimirCadena(char *prmCadena);

/**
*	@brief Funcion para imprimir en consola un arreglo de tipo 'char' y un numero entero.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmNumero: recibe el numero entero.
**/
void imprimirCadenaConNumeroEntero(char *prmCadena, int prmNumero);

/**
*	@brief Funcion para imprimir en consola un arreglo de tipo 'char' y un numero double.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmNumero: recibe el numero double.
**/
void imprimirCadenaConNumeroDouble(char *prmCadena, double prmNumero);

/**
*	@brief Funcion para imprimir en consola un arreglo de tipo 'char' con salto de linea.
*
*	@param prmCadena: recibe el apuntador del arreglo.
**/
void imprimirCadenaConSalto(char *prmCadena);

/**
*	@brief Funcion para imprimir en consola un caracter.
*
*	@param prmCaracter: recibe el caracter.
**/
void imprimirCaracter(char prmCaracter);

/**
*	@brief Funcion para imprimir en consola un caracter con salto de linea.
*
*	@param prmCaracter: recibe el caracter.
**/
void imprimirCaracterConSalto(char prmCaracter);

/**
*	@brief Funcion para imprimir en consola un caracter
*	ASCII que no es imprimible.
*
*	@param prmCaracter: recibe el caracter.
**/
void imprimirCaracterEspecial(char prmCaracter);

/**
*	@brief Funcion para imprimir en consola un caracter
*	ASCII que no es imprimible.
*	Adicionando un salto de linea.
*
*	@param prmCaracter: recibe el caracter.
**/
void imprimirCaracterEspecialConSalto(char prmCaracter);

/**
*	@brief Funcion para imprimir en consola un arreglo de tipo 'char' con caracteres
*	ASCII que no son imprimibles.
*
*	@param prmCadena: recibe el apuntador del arreglo.
**/
void imprimirCadenaEspecial(char *prmCadena);

/**
*	@brief Funcion para imprimir en consola un arreglo de tipo 'char' con caracteres
*	ASCII que no son imprimibles.
*	Adicionando un salto de linea.
*
*	@param prmCadena: recibe el apuntador del arreglo.
**/
void imprimirCadenaEspecialConSalto(char *prmCadena);

/**
*	@brief Funcion para imprimir en consola un caracter con espacio inicial.
*
*	@param prmCantEspacios: recibe la cantidad de caracteres de espacio antes del caracter a imprimir.
*	@param prmCaracter: recibe el caracter a imprimir.
**/
void imprimirCaracterJustificado(int prmCantEspacios, char prmCaracter);

/**
*	@brief Funcion para imprimir en consola un arreglo de tipo 'char' con espacio inicial.
*
*	@param prmCantEspacios: recibe la cantidad de caracteres de espacio antes del arreglo a imprimir.
*	@param prmCadena: recibe el arreglo a imprimir.
**/
void imprimirCadenaJustificada(int prmCantEspacios, char *prmCadena);

/** 
*   @brief Funcion para imprimir un mensaje en consola.
*
*   @param prmMensaje: recibe el mensaje a imprimir.
**/
void imprimirMensaje(char *prmMensaje);

/**
*	@brief Funcion para imprimir en consola un numero entero.
*
*	@param prmNumero: recibe el numero.
**/
void imprimirNumeroEntero(int prmNumero);

/**
*	@brief Funcion para imprimir en consola un numero double.
*
*	@param prmNumero: recibe el numero.
**/
void imprimirNumeroDouble(double prmNumero);

/**
*	@brief Funcion para recibir un arreglo de tipo 'char' por consola.
*
*	@param prmEtiqueta: recibe el apuntador al arreglo de tipo 'char' con la descripcion de la entrada.
*	@param prmDireccion: recibe el apuntador donde se guarda el arreglo recibido.
**/
void recibirCadena(char *prmEtiqueta, char *prmDireccion);

/**
*	@brief Funcion para recibir un caracter por consola.
*
*	@param prmEtiqueta: recibe el apuntador al arreglo de tipo 'char' con la descripcion de la entrada.
*
*	@return El caracter recibido.
**/
char recibirCaracter(char *prmEtiqueta);

/**
*	@brief Funcion para recibir datos de tipo entero por consola.
*
*	@param prmEtiqueta: recibe el apuntador al arreglo de tipo 'char' con la descripcion de la entrada.
*	@param prmDireccion: recibe la direccion de memoria de la variable en que se guarda el dato recibido.
**/
void recibirDatoEntero(char *prmEtiqueta, int *prmDireccion);

/**
*	@brief Funcion para recibir datos de tipo double por consola.
*
*	@param prmEtiqueta: recibe el apuntador al arreglo de tipo 'char' con la descripcion de la entrada.
*	@param prmDireccion: recibe la direccion de memoria de la variable en que se guarda el dato recibido.
**/
void recibirDatoDouble(char *prmEtiqueta, double *prmDireccion);

/**
*	@brief Funcion para limpiar la consola.
**/
void limpiarConsola();

/**
*	@brief Funcion para pausar la ejecucion del programa.
**/
void pausarPrograma();

/**
*	@brief Funcion para finalizar la ejecucion del programa.
**/
void finalizarPrograma();
#endif
