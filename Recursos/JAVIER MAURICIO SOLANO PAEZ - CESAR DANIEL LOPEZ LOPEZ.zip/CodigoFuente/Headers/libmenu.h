#ifndef LIBMENU_H

#define LIBMENU_H
// Autor: javiersolanop

/**
*   @brief Funcion para definir el menu.
*
*    El apuntador sera un arreglo de apuntadores de cadena.
*    Cada apuntador de cadena contiene un item.
*
*   @param prmCantItems: recibe la cantidad de items que debe tener el menu.
*
*    @return El apuntador del menu.
**/
char** definirMenu(int prmCantItems);

/**
*    @brief Funcion para establecer el titulo.
*
*    @param prmMenu: recibe el apuntador del menu.
*    @param prmTitulo: recibe el titulo que identifica al menu.
**/
void establecerTituloMenu(char **prmMenu, char *prmTitulo);

/**
*   @brief Funcion para aniadir un item.
*
*   @param prmMenu: recibe el apuntador del menu.
*   @param prmOpcion: recibe la opcion que se asignara al item.
*                     Debe ser mayor o igual a (1).
*    @param prmItem: recibe la cadena del item.
**/
void aniadirItemMenu(char **prmMenu, int prmOpcion, char *prmItem);

/**
*   @brief Funcion para imprimir el menu.
*
*   @param prmMenu: recibe el apuntador del menu.    
*   @param prmCantItems: recibe la cantidad de items que se  requiere imprimir.
**/
void imprimirMenu(char **prmMenu, int prmCantItems);

/**
*    @brief Funcion para liberar el espacio en memoria de un menu.
*
*    @param prmApuntador: recibe el apuntador del menu.   
*    @param prmCantItems: recibe la cantidad de items que tiene el menu.
**/
void liberarMenu(char **prmApuntador, int prmCantItems);
#endif
