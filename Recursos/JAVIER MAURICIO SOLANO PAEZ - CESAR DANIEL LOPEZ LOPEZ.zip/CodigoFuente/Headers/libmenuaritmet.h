#ifndef LIBMENUARITMET_H

#define LIBMENUARITMET_H
// Autor: javiersolanop

/**
*   @brief Funcion para imprimir en consola el menu.
**/
void imprimirMenuAritmetica();
#endif
