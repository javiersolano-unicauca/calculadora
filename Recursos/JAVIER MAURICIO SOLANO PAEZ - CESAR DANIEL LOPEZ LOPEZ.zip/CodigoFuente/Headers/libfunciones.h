#ifndef LIBFUNCIONES_H

#define LIBFUNCIONES_H
// Autor: javiersolanop

/**
*	@brief Variable en la que se guarda datos temporales.
**/
int glbDatoTemporal;

/**
*   @brief Funcion para guardar datos temporalmente.
*
*    @param prmDato: recibe el dato a guardar.
**/
void guardarDatoEnteroTemporal(int prmDato);

/**
*   @brief Funcion para obtener datos guardados temporalmente.

*   @return El dato guardado en el momento del llamado.
**/
int obtenerDatoEnteroTemporal();

/**
*   @brief Funcion para calcular el factorial de un numero entero.
*          Lo recibe por consola y realiza el calculo.
*          Despues imprime el resultado.
**/
void calcularFactorial();

/**
*   @brief Funcion para calcular la potencia de un numero entero. 
*          Recibe por consola la base y exponente a elevar.
*           Despues imprime el resultado.   
**/
void calcularPotencia();
#endif
