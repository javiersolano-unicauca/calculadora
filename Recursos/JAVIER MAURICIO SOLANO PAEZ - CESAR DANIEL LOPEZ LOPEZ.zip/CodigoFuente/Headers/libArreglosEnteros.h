#ifndef LIBARREGLOSENTEROS_H

#define LIBARREGLOSENTEROS_H

/**
*    @brief Funcion para dimensionar un arreglo de tipo entero.
*
*    @param prmTamanio: recibe la cantidad de elementos que almacena el arreglo.
*
*    @return El apuntador al arreglo.
**/
int* dimensionarArregloEntero(int prmTamanio);

/**
*    @brief Funcion para obtener la cantidad de elementos del arreglo.
*
*    @param prmArreglo: recibe el apuntador del arreglo.
*
*    @return La cantidad de elementos.
**/
int obtenerTamanioArregloEntero(int *prmArreglo);

/**
*    @brief Funcion para liberar el espacio en memoria del arreglo.
*
*   @param prmArreglo: recibe el apuntador del arreglo.
**/
void liberarDimensionArregloEntero(int *prmArreglo);

#endif