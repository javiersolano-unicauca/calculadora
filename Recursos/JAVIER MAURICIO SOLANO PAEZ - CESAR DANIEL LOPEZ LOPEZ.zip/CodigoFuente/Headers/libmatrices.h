#ifndef LIBMATRICES_H

#define LIBMATRICES_H
// Autor: javiersolanop

/**
*   @brief Funcion para dimensionar una matriz de tipo 'int'.
*
*   @param prmM: recibe el apuntador de la cantidad de filas.
*   @param prmN: recibe el apuntador de la cantidad de columnas.
*
*   @return El apuntador de la matriz.
**/
int** dimensionarMatrizDeTipoEntero(int *prmM, int *prmN);

/**
*   @brief Funcion para liberar el espacio en memoria de una matriz.
*
*    @param prmMatriz: recibe el apuntador de la matriz.
*    @param prmM: recibe el apuntador de la cantidad de filas.
**/
void liberarDimensionMatrizDeTipoEntero(int **prmMatriz, int *prmM);

/**
*   @brief Funcion para realizar el llenado de elementos.
*            Los recibe por consola.
*
*    @param prmMatriz: recibe el apuntador de la matriz.
*    @param prmM: recibe el apuntador de la cantidad de filas.
*   @param prmN: recibe el apuntador de la cantidad de columnas.    
**/
void llenarMatriz(int **prmMatriz, int *prmM, int *prmN);

/**
*    @brief Funcion para imprimir en consola los elementos.
*
*   @param prmMatriz: recibe el apuntador de la matriz.
*    @param prmM: recibe el apuntador de la cantidad de filas.
*   @param prmN: recibe el apuntador de la cantidad de columnas.   
**/
void imprimirMatriz(int **prmMatriz, int *prmM, int *prmN);

/**
*    @brief Funcion para recibir los elementos por consola.
*          Despues imprime la matriz obtenida.
*
*    @param prmMatriz: recibe el apuntador de la matriz.
*   @param prmM: recibe el apuntador de la cantidad de filas.
*   @param prmN: recibe el apuntador de la cantidad de columnas. 
**/
void recibirElementosDeMatrizDeTipoEntero(int **prmMatriz, int *prmM, int *prmN);

/**
*   @brief Funcion para sumar los elementos de dos matrices, empleando conceptos de 'Algebra lineal'.
*           Por lo tanto, para poder realizar la operacion, (A) Y (B)
*           deben tener las misma dimensiones. Las cuales son recibidas por consola.
*           Por ultimo, imprime el resultado.
**/
void sumarMatricesDeTipoEntero();

/**
*   @brief Funcion para multiplicar los elementos de dos matrices, empleando conceptos de 'Algebra lineal'.
*          Por lo tanto, para poder realizar la operacion, la cantidad de columnas de (A)
*           debe ser la misma que de filas de (B). Sus dimensiones son recibidas por consola. 
*          Por ultimo, imprime el resultado.
**/
void multiplicarMatricesDeTipoEntero();

/**
*   @brief Funcion para multiplicar cada elemento por un escalar, empleando conceptos de 'Algebra lineal'.
*          Las dimensiones de la matriz son recibidas por consola. Por ultimo, imprime el resultado.
**/
void multiplicarEscalarTipoEnteroPorMatrizTipoEntero();
#endif
