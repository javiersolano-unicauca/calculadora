#ifndef LIBMENUARBOLES_H

#define LIBMENUARBOLES_H
// Autor: javiersolanop

/**
*   @brief Funcion para imprimir en consola el menu.
**/
void imprimirMenuArboles();
#endif
