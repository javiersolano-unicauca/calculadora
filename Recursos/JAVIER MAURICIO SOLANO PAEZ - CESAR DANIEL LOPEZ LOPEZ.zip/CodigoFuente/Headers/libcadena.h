#ifndef LIBCADENA_H

#define LIBCADENA_H
// Autor: javiersolanop

/**
*	@brief Funcion para dimensionar un arreglo de tipo 'char'.
*
*	@param prmTamanio: recibe el tamanio que debe tener el arreglo.
*
*	@return El apuntador al arreglo.
**/
char* dimensionarApuntadorCadena(int prmTamanio);

/**
*	@brief Funcion para dimensionar una matriz de tipo 'char'.
*
*	@param prmTamanioApuntador: recibe la cantidad de apuntadores de cadena que debe tener la matriz.
*	@param prmTamanioApuntadorCadena: recibe el tamanio que debe tener cada apuntador de cadena.
*
*	@return El apuntador a la matriz.
**/
char** dimensionarApuntadorDeApuntadorCadena(int prmTamanioApuntador, int prmTamanioApuntadorCadena);

/**
*	@brief Funcion para dimensionar una matriz de tipo 'char'.
*
*	@param prmTamanioApuntador: recibe la cantidad de apuntadores de cadena que debe tener la matriz.
*
*	@return El apuntador a la matriz.
**/
char **dimensionarApuntadorDeApuntadorCadenaSinApuntadores(int prmTamanioApuntador);

/**
*	@brief Funcion para liberar el espacio en memoria de un arreglo de tipo 'char'.
*
*	@param prmApuntador: recibe el apuntador del arreglo.
**/
void liberarDimensionApuntadorCadena(char *prmApuntador);

/**
*	@brief Funcion para liberar el espacio en memoria de una matriz de tipo 'char'.
*
*	@param prmApuntador: recibe el apuntador de la matriz.
*	@param prmTamanioApuntador: recibe la cantidad de apuntadores de cadena que tiene la matriz.
**/
void liberarDimensionApuntadorDeApuntadorCadena(char **prmApuntador, int prmTamanioApuntador);

/**
*	@brief Funcion para obtener la cantidad de caracteres que tiene un arreglo de tipo 'char'.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*
*	@return La cantidad de caracteres.
**/
int obtenerTamanioCadena(char *prmCadena);

/**
*	@brief Funcion para reinicializar un arreglo de tipo 'char'.
*
*	@param prmCadena: recibe el apuntador del arreglo.
**/
void limpiarCadenaDeApuntador(char* prmCadena);

/**
*	@brief Funcion para reinicializar las posiciones de un arreglo de tipo 'char'.
*		   En donde se encuentren caracteres ASCII que no son imprimibles.
*	
*	@param prmCadena: recibe el apuntador del arreglo.
**/
void depurarCadenaDeApuntador(char *prmCadena);

/**
*	@brief Funcion para concatenar un arreglo de tipo 'char' con un caracter.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmCaracter: recibe el caracter que se debe concatenar.
*	@param prmCadenaNueva: recibe el apuntador donde se guarda el arreglo resultante.
**/
void concatenarCadenaConCaracter(char *prmCadena, char prmCaracter, char *prmCadenaNueva);

/**
*	@brief Funcion para concatenar dos arreglos de tipo 'char'.
*
*	@param prmCadena1: recibe el apuntador del primer arreglo.
*	@param prmCadena2: recibe el apuntador del segundo arreglo.
*	@param prmCadenaNueva: recibe el apuntador donde se guarda el arreglo resultante.
**/
void concatenarCadenas(char *prmCadena1, char* prmCadena2, char *prmCadenaNueva);

/**
*	@brief Funcion para repetir un caracter en un arreglo de tipo 'char'.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmCaracter: recibe el caracter que se repite.
*	@param prmN: recibe la cantidad de veces que se repite el caracter en el arreglo.
**/
void repetirCaracter(char *prmCadena, char prmCaracter, int *prmN);

/**
*	@brief Funcion para validar si dos arreglos de tipo 'char' poseen los mismos caracteres.
*
*	@param prmCadena1: recibe el apuntador del primer arreglo.
*	@param prmCadena2: recibe el apuntador del segundo arreglo.
*
*	@return 1 si poseen los mismos caracteres. 
*	0 si no tienen la misma cantidad de caracteres o no poseen los mismos caracteres.
**/
int validarCadenasIguales(char *prmCadena1, char *prmCadena2);

/**
*	@brief Funcion para eliminar un caracter de un arreglo de tipo 'char'.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmCaracter: recibe el caracter a eliminar.
*	@param prmNuevaCadena: recibe el apuntador donde se guarda el arreglo resultante.
**/
void eliminarCaracterDeCadena(char *prmCadena, char prmCaracter, char *prmNuevaCadena);

/**
*	@brief Funcion para extraer caracteres de un arreglo de tipo 'char'.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmIndice: recibe el indice donde empieza la extraccion.
*	@param prmNuevaCadena: recibe el apuntador donde se guarda el arreglo resultante. 
**/
void extraerSubCadenaDeCadena(char *prmCadena, int prmIndice, char *prmNuevaCadena);

/**
*	@brief Funcion para extraer caracteres de forma dinamica en un arreglo de tipo 'char'.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmIndiceInicial: recibe el indice donde empieza la extraccion.
*	@param prmIndiceFinal: recibe el indice donde se termina la extraccion.
*	@param prmNuevaCadena: recibe el apuntador donde se guarda el arreglo resultante. 
**/
void extraerSubCadenaDinamicaDeCadena(char *prmCadena, int prmIndiceInicial, int prmIndiceFinal, char *prmNuevaCadena);

/**
*	@brief Funcion para eliminar caracteres de un arreglo de tipo 'char'.
*
*	@param prmCadena: recibe el apuntador del arreglo en el que se eliminan caracteres.
*	@param prmSubCadena: recibe el apuntador del arreglo con los caracteres a eliminar.
*	@param prmNuevaCadena: recibe el apuntador donde se guarda el arreglo resultante. 
**/
void eliminarSubCadenaDeCadena(char *prmCadena, char *prmSubCadena, char *prmNuevaCadena);

/**
*	@brief Funcion parar buscar un caracter en un arreglo de tipo 'char'.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmCaracter: recibe el caracter a buscar.
*
*	@return El indice del caracter en el arreglo. -1 si no se encuentra el caracter.
**/
int encontrarIndiceCaracterDeCadena(char *prmCadena, char prmCaracter);

/**
*	@brief Funcion para encontrar los indices en los que se repite un caracter en una cadena.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmCaracter: recibe el caracter a buscar.
*
*	@return El arreglo con los indices donde se encuentra el caracter.
*	Si no se encuentra el caracter en la cadena, se guarda un -1 en el indice
*	0 del arreglo retornado.
**/
int* encontrarIndicesDeCaracterDeCadena(char *prmCadena, char prmCaracter);

/**
*	@brief Funcion para contar las veces que se repite un caracter en un arreglo de tipo 'char'.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmCaracter: recibe el caracter a validar.
*
*	@return La cantidad de veces que se repite.
**/
int contarCaracterRepetidoDeCadena(char *prmCadena, char prmCaracter);

/**
*	@brief Funcion para recortar un arreglo de tipo 'char'.
*		   Extrae los arreglos hasta el indice indicado.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmIndice: recibe el indice donde termina la extraccion.
*	@param prmNuevaCadena: recibe el apuntador donde se guarda el arreglo resultante. 
**/
void recortarCadena(char *prmCadena, int prmIndice, char *prmNuevaCadena);

/**
*	@brief Funcion para copiar los caracteres de un arreglo de tipo 'char' en otro del mismo tipo.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmCadenaClonada: recibe el apuntador donde se guarda el arreglo resultante. 
**/
void clonarCadena(char *prmCadena, char *prmCadenaClonada);

/**
*	@brief Funcion para reemplazar caracteres de espacio en un arreglo de tipo 'char'.
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmCaracterDeReemplazo: recibe el caracter reemplazante. 
**/
void reemplazarCaracteresDeEspacioDeCadena(char *prmCadena, char prmCaracterDeReemplazo);

/**
*	@brief Funcion para reemplazar un caracter de un arreglo de tipo 'char'. 
*
*	@param prmCadena: recibe el apuntador del arreglo.
*	@param prmIndice: recibe el indice donde se reemplaza con el caracter.
*	@param prmCaracter: recibe el caracter reemplazante. 
**/
void reemplazarCaracterDeCadena(char *prmCadena, int prmIndice, char prmCaracter);
#endif
