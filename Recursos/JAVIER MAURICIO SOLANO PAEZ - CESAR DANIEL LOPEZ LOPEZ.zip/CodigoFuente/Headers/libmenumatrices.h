#ifndef LIBMENUMATRICES_H

#define LIBMENUMATRICES_H
// Autor: javiersolanop

/**
*   @brief Funcion para imprimir en consola el menu.
**/
void imprimirMenuMatrices();
#endif
