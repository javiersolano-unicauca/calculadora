#ifndef LIBMENUFUNCIONES_H

#define LIBMENUFUNCIONES_H
// Autor: javiersolanop

/**
*   @brief Funcion para imprimir en consola el menu.
**/
void imprimirMenuFunciones();
#endif
