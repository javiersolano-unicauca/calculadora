#ifndef LIBMENUGRAFICAS_H

#define LIBMENUGRAFICAS_H
// Autor: javiersolanop

/**
*   @brief Funcion para imprimir en consola el menu.
**/
void imprimirMenuGraficas();
#endif
