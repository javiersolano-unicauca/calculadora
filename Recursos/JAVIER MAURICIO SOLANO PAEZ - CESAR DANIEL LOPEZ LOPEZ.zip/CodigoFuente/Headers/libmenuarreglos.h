#ifndef LIBMENUARREGLOS_H

#define LIBMENUARREGLOS_H
// Autor: javiersolanop

/**
*   @brief Funcion para imprimir en consola el menu.
**/
void imprimirMenuArreglos();
#endif
