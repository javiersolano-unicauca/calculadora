#ifndef LIBARITMETICA_H

#define LIBARITEMETICA_H
// Autor: javiersolanop

/**
*    @brief Funcion para imprimir el resultado en consola.
*           Si el resultado es de tipo entero, lo imprime sin cifras decimales.
*    
*    @param prmResultado: recibe el resultado a imprimir.
**/
void imprimirResultadoAritmetico(double *prmResultado);

/**
*    @brief Funcion para sumar dos numeros de tipo 'double'.
*
*    @param prmNumero1: recibe el primer operando.
*    @param prmNumero2: recibe el segundo operando.
**/
void sumar(double *prmNumero1, double *prmNumero2);

/**
*    @brief Funcion para restar dos numeros de tipo 'double'.
*
*    @param prmNumero1: recibe el primer operando.
*    @param prmNumero2: recibe el segundo operando.
*/
void restar(double *prmNumero1, double *prmNumero2);

/**
*    @brief Funcion para multiplicar dos numeros de tipo 'double'.
*
*    @param prmNumero1: recibe el primer operando.
*    @param prmNumero2: recibe el segundo operando.
**/
void multiplicar(double *prmNumero1, double *prmNumero2);

/**
*    @brief Funcion para dividir dos numeros de tipo 'double'.
*
*    @param prmNumero1: recibe el primer operando.
*    @param prmNumero2: recibe el segundo operando.
**/
void dividir(double *prmNumero1, double *prmNumero2);
#endif
