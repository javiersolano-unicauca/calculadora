#ifndef LIBGRAFICAS_H

#define LIBGRAFICAS_H
// Autor: javiersolanop

/**
*   @brief Funcion para imprimir en consola la figura geometrica.
*           Recibe en consola la longitud de su lado.
**/
void imprimirCuadrado();

/**
*   @brief Funcion para imprimir en consola la figura geometrica.
*          Recibe en consola su base y altura.
**/
void imprimirRectangulo();

/**
*   @brief Funcion para imprimir en consola la figura de un triangulo equilatero.
*          Recibe en consola su base.
**/
void imprimirTriangulo();

/**
*   @brief Funcion para imprimir en consola la figura geometrica.
*   
*   @param prmBaseMenor: recibe la base menor del trapecio.
**/
void imprimirTrapecioIsoscelesSinEntradaConsola(int *prmBaseMenor);

/**
*   @brief Funcion para imprimir en consola el arbol de tipo '°'.
*          Recibe en consola su altura, no mayor a (44).
**/
void imprimirArbolSencillo();

/**
*    @brief Funcion para imprimir en consola el arbol de tipo '°+°+°'.
*           Recibe en consola su altura.
**/
void imprimirArbolCompuesto();

/**
*   @brief Funcion para imprimir en consola el arbol de tipo '123...'.
*           Recibe en consola su altura.
**/
void imprimirArbolNumerico();

/**
*   @brief Funcion para imprimir en consola el arbol de tipo '1-2-3...'.
*          Recibe en consola su altura.
**/
void imprimirArbolNumericoConSeparador();

#endif
