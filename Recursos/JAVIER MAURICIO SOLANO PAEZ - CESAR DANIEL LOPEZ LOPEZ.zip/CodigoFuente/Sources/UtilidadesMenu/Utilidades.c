/**
*   @brief Funcion para recibir por consola la opcion del usuario.
**/
void recibirOpcion(int *prmOpcion)
{
    imprimirCaracterConSalto(' ');
    recibirDatoEntero("Ingrese una opcion", prmOpcion);
}

/**
*   @brief Funcion para imprimir en consola el error.
**/
void imprimirOpcionInvalida()
{
    imprimirMensaje("Opcion invalida...");
}

/**
*    @brief Funcion para validar una opcion del menu.
*    Si no es valida, imprime la excepcion y limpia la consola.
*
*   @param prmOpcion: recibe el apuntador de la opcion a validar.
*    @param prmOpcionSalida: recibe el apuntador de la opcion de salida del menu.
*
*   @return  (1) si corresponde a la opcion de salida.
*           Si no (0).
*
**/
int validarOpcion(int *prmOpcion, int *prmOpcionSalida)
{
    if((*prmOpcion < 1) || (*prmOpcion > *prmOpcionSalida)){
     
        imprimirOpcionInvalida();
        pausarPrograma(); // Esperamos que el usuario lea la excepcion.
        limpiarConsola();
        return 0;
    }
    return 1;
}

/**
*   @brief Funcion para esperar la lectura de consola.
*           Pausa la ejecucion del programa hasta que el usuario
*            presione cualquier tecla.
**/
void esperarLectura()
{
    imprimirCadenaConSalto(" ");
    imprimirCadenaConSalto(" ");
    pausarPrograma(); // Espera que el usuario lea la salida.
}
