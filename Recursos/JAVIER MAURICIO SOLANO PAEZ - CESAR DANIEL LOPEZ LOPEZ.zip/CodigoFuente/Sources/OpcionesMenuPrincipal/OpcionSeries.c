#include "../Librerias/libmenuseries.c"

void realizarOpcionSeries()
{
	imprimirMenuSeries();
    /*
        Aqui van las opciones del menu.
    */
}