#include "../Librerias/libmenuaritmet.c"
#include "../Librerias/libaritmetica.c"

void realizarOpcionAritmetica()
{
    int varOpcion;
    double varNumero1, varNumero2; // Operando.

    do{

        imprimirMenuAritmetica();
        recibirOpcion(&varOpcion);

        // Si la opcion recibida corresponde a la de la salida del menu, rompemos la iteracion del bucle.
        if(varOpcion == glbSalidaMenuAritmetica)
            break;
        
        else if(!validarOpcion(&varOpcion, &glbSalidaMenuAritmetica))
            continue;
        
        imprimirCaracterConSalto(' ');
        recibirDatoDouble("Ingrese el valor del primer numero", &varNumero1);
        recibirDatoDouble("Ingrese el valor del segundo numero", &varNumero2);

        switch (varOpcion)
        {
            case 1: sumar(&varNumero1, &varNumero2); 
            break;

            case 2: restar(&varNumero1, &varNumero2); 
            break;

            case 3: multiplicar(&varNumero1, &varNumero2); 
            break;

            case 4: dividir(&varNumero1, &varNumero2); 
            break;
        }

        esperarLectura();
        limpiarConsola(); // Limpia nuevamente la consola para que solo sea visible el menu.

    }while(1);
}