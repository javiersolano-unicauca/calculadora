#include "../Librerias/libmenumatrices.c"
#include "../Librerias/libmatrices.c"

void realizarOpcionMatrices()
{
    int varOpcion;

    do{

        imprimirMenuMatrices();
        recibirOpcion(&varOpcion);

        // Si la opcion recibida corresponde a la de la salida del menu, rompemos la iteracion del bucle.
        if(varOpcion == glbSalidaMenuMatrices)
            break;

        else if(!validarOpcion(&varOpcion, &glbSalidaMenuMatrices))
            continue;    

        imprimirCaracterConSalto(' ');

        switch(varOpcion)
        {
            case 1: multiplicarMatricesDeTipoEntero();
            break;

            case 2: multiplicarEscalarTipoEnteroPorMatrizTipoEntero();
            break;
        }

        esperarLectura();
        limpiarConsola(); // Limpia nuevamente la consola para que solo sea visible el menu.

    }while(1);
}