#include "../Librerias/libmenugraficas.c"
#include "../Librerias/libgraficas.c"
#include "./OpcionesMenuGraficas/OpcionArboles.c"

void realizarOpcionGrafica()
{
    int varOpcion;

    do{

        imprimirMenuGraficas();
        recibirOpcion(&varOpcion);

        // Si la opcion recibida corresponde a la de la salida del menu, rompemos la iteracion del bucle.
        if(varOpcion == glbSalidaMenuGraficas)
            break;

        else if(!validarOpcion(&varOpcion, &glbSalidaMenuGraficas))
            continue;    

        imprimirCaracterConSalto(' ');

        switch (varOpcion)
        {
            case 1: imprimirCuadrado();
            break;

            case 2: imprimirRectangulo();
            break;

            case 3: imprimirTriangulo();
            break;

            case 4:
            {
                limpiarConsola(); // Limpiamos la consola para que solamente sea visible el menu de los arboles.
                realizarOpcionArboles();
            }
            break;
        }

        esperarLectura();
        limpiarConsola(); // Limpia nuevamente la consola para que solo sea visible el menu.

    }while(1);
}