#include "../../Librerias/libmenuarboles.c"

void realizarOpcionArboles()
{
    int varOpcion;

    do{

        imprimirMenuArboles();

        imprimirCaracterConSalto(' ');
        recibirOpcion(&varOpcion);

        // Si la opcion recibida corresponde a la de la salida del menu, rompemos la iteracion del bucle.
        if(varOpcion == glbSalidaMenuArboles)
            break;

        imprimirCaracterConSalto(' ');

        switch (varOpcion)
        {
            case 1: imprimirArbolSencillo();
            break;

            case 2: imprimirArbolCompuesto();
            break;

            case 3: imprimirArbolNumerico();
            break;

            case 4: imprimirArbolNumericoConSeparador();
            break;

            default:
                imprimirOpcionInvalida();
            break;
        }

        esperarLectura();
        limpiarConsola(); // Limpia nuevamente la consola para que solo sea visible el menu.

    }while (1);
}