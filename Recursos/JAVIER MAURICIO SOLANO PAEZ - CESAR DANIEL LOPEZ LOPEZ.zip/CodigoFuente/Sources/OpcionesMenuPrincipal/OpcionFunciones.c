#include "../Librerias/libmenufunciones.c"
#include "../Librerias/libfunciones.c"

void realizarOpcionFunciones()
{
    int varOpcion;

    do{

        imprimirMenuFunciones();
        recibirOpcion(&varOpcion);

        // Si la opcion recibida corresponde a la de la salida del menu, rompemos la iteracion del bucle.
        if(varOpcion == glbSalidaMenuFunciones)
            break;

        else if(!validarOpcion(&varOpcion, &glbSalidaMenuFunciones))
            continue;

        imprimirCaracterConSalto(' ');

        switch (varOpcion)
        {
            case 1: calcularFactorial();
            break;

            case 2: calcularPotencia();
            break;
        }

        esperarLectura();
        limpiarConsola(); // Limpia nuevamente la consola para que solo sea visible el menu.

    }while(1);
}