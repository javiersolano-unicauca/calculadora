#include "../Librerias/libmenuarreglos.c"
#include "../Librerias/libarreglos.c"

void realizarOpcionArreglos()
{
    int varOpcion, varTamanio;

    do{

        imprimirMenuArreglos();
        recibirOpcion(&varOpcion);

        // Si la opcion recibida corresponde a la de la salida del menu, rompemos la iteracion del bucle.
        if(varOpcion == glbSalidaMenuArreglos)
            break;
                    
        else if(!validarOpcion(&varOpcion, &glbSalidaMenuArreglos))
            continue;
        
        recibirDatoEntero("Ingrese la cantidad de elementos que va tener el arreglo de tipo entero", &varTamanio);
        imprimirCaracterConSalto(' ');

        switch (varOpcion)
        {
            case 1: sumarElementosDeArregloDeTipoDouble(&varTamanio);
            break;

            case 2: restarElementosDeArregloDeTipoDouble(&varTamanio);
            break;

            case 3: multiplicarElementosDeArregloDeTipoDouble(&varTamanio);
            break;

            case 4: dividirElementosDeArregloDeTipoDouble(&varTamanio);
            break;

            case 5: ordenarElementosDeArregloDeTipoDouble(&varTamanio);
            break;

            case 6: reversarElementosDeArregloDeTipoDouble(&varTamanio);
            break;

            case 7: multiplicarElementosDeArregloDeTipoDoublePorEscalar(&varTamanio);
            break;
        }

        esperarLectura();
        limpiarConsola(); // Limpia nuevamente la consola para que solo sea visible el menu.

    }while(1);
}
