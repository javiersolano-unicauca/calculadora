#include "./MenuPrincipal.c"

int main()
{
	correrMenuPrincipal();
	finalizarPrograma();	
}