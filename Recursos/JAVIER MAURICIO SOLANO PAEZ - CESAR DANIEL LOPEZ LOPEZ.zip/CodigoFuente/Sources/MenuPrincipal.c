#include "./Librerias/libmenu.c"
#include "./UtilidadesMenu/Utilidades.c"

// Incluimos los menus de las opciones.
#include "./OpcionesMenuPrincipal/OpcionAritmetica.c"
#include "./OpcionesMenuPrincipal/OpcionFunciones.c"
#include "./OpcionesMenuPrincipal/OpcionSeries.c"
#include "./OpcionesMenuPrincipal/OpcionArreglos.c"
#include "./OpcionesMenuPrincipal/OpcionMatrices.c"
#include "./OpcionesMenuPrincipal/OpcionGraficas.c"

/**
*  @brief Variable global que controla la salida del menu principal.
**/
int glbSalidaMenuPrincipal;

/**
*	@brief Funcion para imprimir en consola el menu.
**/
void imprimirMenuPrincipal()
{
	// Cantidad de items de opciones que tendra el menu.
    int varCantItemsMenu = 7, varOpcion = 0;

    // Apuntador de apuntadores de los items del menu.
    char **ptrMenu = definirMenu(varCantItemsMenu);
    establecerTituloMenu(ptrMenu, "MENU PRINCIPAL");

    // Establecemos las opciones del menu.
    aniadirItemMenu(ptrMenu, ++varOpcion, "Operaciones Aritmeticas...");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Funciones Especiales...");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Series...");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Operaciones con Arreglos...");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Operaciones con Matrices...");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Utilidades Graficas...");

    // Asignamos la opcion que corresponde a la salida del menu.
    aniadirItemMenu(ptrMenu, ++varOpcion, "Salir del menu.");
    glbSalidaMenuPrincipal = varOpcion;

    imprimirMenu(ptrMenu, varCantItemsMenu);
    liberarMenu(ptrMenu, varCantItemsMenu); // Liberamos el espacio en memoria del menu.
}

/**
*	@brief Funcion para correr la ejecucion del menu.
**/
void correrMenuPrincipal()
{
	int varOpcion; // Recibe las opciones que ingrese el usuario.

	do{

		imprimirMenuPrincipal();
		recibirOpcion(&varOpcion);
		
		limpiarConsola(); // Limpiamos la consola para que solo sea visible el menu de la opcion elegida por el usuario.

		// Si la opcion recibida corresponde a la de la salida del menu, rompemos la iteracion del bucle.
		if(varOpcion == glbSalidaMenuPrincipal)
			break;

		switch (varOpcion)
		{
			case 1:	realizarOpcionAritmetica();
			break;

			case 2: realizarOpcionFunciones();
			break;

			case 3: realizarOpcionSeries();
			break;

			case 4: realizarOpcionArreglos();
			break;
			
			case 5: realizarOpcionMatrices();
			break;

			case 6: realizarOpcionGrafica();
			break;

			default: imprimirOpcionInvalida();
		}

		esperarLectura();
		limpiarConsola(); // Limpia nuevamente la consola para que solo sea visible el menu principal.

	}while (varOpcion != glbSalidaMenuPrincipal);
}
