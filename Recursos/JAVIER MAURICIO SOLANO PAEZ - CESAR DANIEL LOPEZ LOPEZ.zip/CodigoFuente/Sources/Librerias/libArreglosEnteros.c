#include "../../Headers/libArreglosEnteros.h"
#include <stdlib.h>

int* dimensionarArregloEntero(int prmTamanio){
    
    int *ptrArreglo = (int *) malloc(prmTamanio * sizeof(int));

    for(int i = 0; i < prmTamanio; i++)
        ptrArreglo[i] = -1;
    return ptrArreglo;
}

int obtenerTamanioArregloEntero(int *prmArreglo)
{
    int varIterador = 0;

    while(1){

        if(prmArreglo[varIterador] > -1)
            varIterador++;
        else
            break;
    }
    return varIterador;
}

void liberarDimensionArregloEntero(int *prmArreglo)
{
    free(prmArreglo);
}