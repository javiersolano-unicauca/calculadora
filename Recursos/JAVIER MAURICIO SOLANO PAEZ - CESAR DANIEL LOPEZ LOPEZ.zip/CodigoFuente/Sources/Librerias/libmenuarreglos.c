#include "../../Headers/libmenuarreglos.h"

/**
* @brief variable goblal que controla la salida del menu arreglos.
**/
int glbSalidaMenuArreglos;

void imprimirMenuArreglos()
{
    // Cantidad de items de opciones que tendra el menu.
    int varCantItemsMenu = 8, varOpcion = 0;

    // Apuntador de apuntadores de los items del menu.
    char **ptrMenu = definirMenu(varCantItemsMenu);
    establecerTituloMenu(ptrMenu, "MENU OPERACIONES CON ARREGLOS");

    // Establecemos las opciones del menu.
    aniadirItemMenu(ptrMenu, ++varOpcion, "Suma Items del Arreglo.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Resta Items del Arreglo.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Producto Items del Arreglo.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Division Items del Arreglo.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Ordenar Items del Arreglo." );
    aniadirItemMenu(ptrMenu, ++varOpcion, "Reversar Items del Arreglo.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Multiplicar Items del Arreglo por Escalar.");

    // Asignamos la opcion que corresponde a la salida del menu.
    aniadirItemMenu(ptrMenu, ++varOpcion, "Salir del menu.");
    glbSalidaMenuArreglos = varOpcion;

    imprimirMenu(ptrMenu, varCantItemsMenu);
    liberarMenu(ptrMenu, varCantItemsMenu); // Liberamos el espacio en memoria del menu.
}
