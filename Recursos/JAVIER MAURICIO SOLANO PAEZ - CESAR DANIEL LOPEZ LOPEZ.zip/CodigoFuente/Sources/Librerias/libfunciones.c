#include "../../Headers/libfunciones.h"

void guardarDatoEnteroTemporal(int prmDato)
{
    glbDatoTemporal = prmDato;
}

int obtenerDatoEnteroTemporal()
{
    return glbDatoTemporal;
}

void calcularFactorial()
{
    int varNumero, varProducto;

    recibirDatoEntero("Ingrese el numero de tipo entero a calcular", &varNumero);
    imprimirCaracterConSalto(' ');

    varProducto = varNumero;

    while(varNumero > 1){

        imprimirNumeroEntero(varNumero);
        imprimirCadena(" * ");

        varProducto *= (varNumero-1);
        varNumero--;
    }

    imprimirNumeroEntero(1);
    imprimirCadenaConNumeroEntero(" = ", varProducto);
}

void calcularPotencia()
{
    int varBase, varProducto, varExponente;

    recibirDatoEntero("Ingrese la base de tipo entero", &varBase);
    recibirDatoEntero("Ingrese el exponente de tipo entero", &varExponente);
    imprimirCaracterConSalto(' ');

    varProducto = varBase;

    while(varExponente > 1){

        imprimirNumeroEntero(varBase);
        imprimirCadena(" * ");

        varProducto *= varBase;
        varExponente--;
    }

    imprimirNumeroEntero(varBase);
    imprimirCadenaConNumeroEntero(" = ", varProducto);
}