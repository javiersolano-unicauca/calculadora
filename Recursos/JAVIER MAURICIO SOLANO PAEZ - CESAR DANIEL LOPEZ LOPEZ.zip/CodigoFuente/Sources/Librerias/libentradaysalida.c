#include "../../Headers/libentradaysalida.h"
#include "./libcadena.c"
#include <stdio.h>
#include <wchar.h>
#include <locale.h>

void imprimirCadena(char *prmCadena)
{
	int varTamanio = obtenerTamanioCadena(prmCadena);

	for(int i = 0; i < varTamanio; i++) {
		printf("%c", prmCadena[i]);
	}
}

void imprimirCadenaConNumeroEntero(char *prmCadena, int prmNumero)
{
	int varTamanio = obtenerTamanioCadena(prmCadena);

	for(int i = 0; i < varTamanio; i++) {
		printf("%c", prmCadena[i]);
	}
	printf("%i", prmNumero);
}

void imprimirCadenaConNumeroDouble(char *prmCadena, double prmNumero)
{
	int varTamanio = obtenerTamanioCadena(prmCadena);

	for(int i = 0; i < varTamanio; i++) {
		printf("%c", prmCadena[i]);
	}
	printf("%.2lf", prmNumero);
}

void imprimirCadenaConSalto(char *prmCadena)
{
	int varTamanio = obtenerTamanioCadena(prmCadena);

	for(int i = 0; i < varTamanio; i++) {
		printf("%c", prmCadena[i]);
	}
	printf("\n");
}

void imprimirCaracter(char prmCaracter)
{
	printf("%c", prmCaracter);
}

void imprimirCaracterConSalto(char prmCaracter)
{
	printf("%c\n", prmCaracter);
}

void imprimirCaracterEspecial(char prmCaracter)
{
	setlocale(LC_ALL, "");
	printf("%c", prmCaracter);
}

void imprimirCaracterEspecialConSalto(char prmCaracter)
{
	setlocale(LC_ALL, "");
	printf("%c\n", prmCaracter);
}

void imprimirCadenaEspecial(char *prmCadena)
{
	int varTamanio = obtenerTamanioCadena(prmCadena);
	setlocale(LC_ALL, "");

	for(int i = 0; i < varTamanio; i++) {
		printf("%c", prmCadena[i]);
	}
	printf("\n");
}

void imprimirCadenaEspecialConSalto(char *prmCadena)
{
	int varTamanio = obtenerTamanioCadena(prmCadena);
	setlocale(LC_ALL, "");

	for(int i = 0; i < varTamanio; i++) {
		printf("%c", prmCadena[i]);
	}
	printf("\n");
}

void imprimirCaracterJustificado(int prmCantEspacios, char prmCaracter)
{
	for(int i = 0; i < prmCantEspacios; i++){

        if(i < (prmCantEspacios-1))
            imprimirCaracter(' ');
        else
            imprimirCaracterConSalto(prmCaracter);
    }
}

void imprimirCadenaJustificada(int prmCantEspacios, char *prmCadena)
{
    for(int i = 0; i < prmCantEspacios; i++){

        if(i < (prmCantEspacios-1))
            imprimirCaracter(' ');
        else
            imprimirCadenaConSalto(prmCadena);
    }
}

void imprimirMensaje(char *prmMensaje)
{
    imprimirCaracterConSalto(' ');
    imprimirCadenaConSalto(prmMensaje);
    imprimirCaracterConSalto(' ');
}

void imprimirNumeroEntero(int prmNumero)
{
	printf("%i", prmNumero);
}

void imprimirNumeroDouble(double prmNumero)
{
	printf("%.2lf", prmNumero);
}

void recibirCadena(char *prmEtiqueta, char *prmDireccion)
{
	printf("%s: ", prmEtiqueta);
	scanf("%s", prmDireccion);
}

char recibirCaracter(char *prmEtiqueta)
{
	char varCaracter;
	printf("%s: ", prmEtiqueta);
	scanf("%s", &varCaracter);
	return varCaracter;
}

void recibirDatoEntero(char *prmEtiqueta, int *prmDireccion)
{
	printf("%s: ", prmEtiqueta);
	scanf("%i", prmDireccion);
}

void recibirDatoDouble(char *prmEtiqueta, double *prmDireccion)
{
	printf("%s: ", prmEtiqueta);
	scanf("%lf", prmDireccion);
}

void limpiarConsola()
{
	system("cls");
}

void pausarPrograma()
{
	system("pause");
}

void finalizarPrograma()
{
    exit(EXIT_SUCCESS);
}
