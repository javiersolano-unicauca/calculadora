#include "../../Headers/libmenuaritmet.h"

/**
* @brief variable goblal que controla la salida del menu aritmetica.
**/
int glbSalidaMenuAritmetica;

void imprimirMenuAritmetica()
{
    // Cantidad de items de opciones que tendra el menu.
    int varCantItemsMenu = 5, varOpcion = 0;

    // Apuntador de apuntadores de los items del menu.
    char **ptrMenu = definirMenu(varCantItemsMenu);
    establecerTituloMenu(ptrMenu, "MENU OPERACIONES ARITMETICAS");

    // Establecemos las opciones del menu.
    aniadirItemMenu(ptrMenu, ++varOpcion, "Operacion de sumar.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Operacion de restar.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Operacion de multiplicar.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Operacion de dividir.");

    // Asignamos la opcion que corresponde a la salida del menu.
    aniadirItemMenu(ptrMenu, ++varOpcion, "Salir del menu.");
    glbSalidaMenuAritmetica = varOpcion;
    
    imprimirMenu(ptrMenu, varCantItemsMenu);
    liberarMenu(ptrMenu, varCantItemsMenu); // Liberamos el espacio en memoria del menu.
}
