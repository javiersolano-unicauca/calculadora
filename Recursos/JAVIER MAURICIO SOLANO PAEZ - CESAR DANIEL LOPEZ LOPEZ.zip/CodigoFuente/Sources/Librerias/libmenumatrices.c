#include "../../Headers/libmenumatrices.h"

/**
* @brief variable goblal que controla la salida del menu matrices.
**/
int glbSalidaMenuMatrices;

void imprimirMenuMatrices()
{
    // Cantidad de items de opciones que tendra el menu.
    int varCantItemsMenu = 3, varOpcion = 0;

    // Apuntador de apuntadores de los items del menu.
    char **ptrMenu = definirMenu(varCantItemsMenu);
    establecerTituloMenu(ptrMenu, "MENU OPERACIONES CON MATRICES");

    // Establecemos las opciones del menu.
    aniadirItemMenu(ptrMenu, ++varOpcion, "Producto.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Multiplicar por Escalar.");

    // Asignamos la opcion que corresponde a la salida del menu.
    aniadirItemMenu(ptrMenu, ++varOpcion, "Salir del menu.");
    glbSalidaMenuMatrices = varOpcion;
    
    imprimirMenu(ptrMenu, varCantItemsMenu);
    liberarMenu(ptrMenu, varCantItemsMenu); // Liberamos el espacio en memoria del menu.
}
