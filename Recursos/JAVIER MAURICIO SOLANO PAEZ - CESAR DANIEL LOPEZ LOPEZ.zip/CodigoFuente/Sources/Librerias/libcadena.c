#include "../../Headers/libcadena.h"
#include "./libArreglosEnteros.c"
#include <stdlib.h>

char* dimensionarApuntadorCadena(int prmTamanio)
{
	return (char*) calloc(prmTamanio, sizeof(char));
}

char** dimensionarApuntadorDeApuntadorCadena(int prmTamanioApuntador, int prmTamanioApuntadorCadena)
{
	char **ptrApuntador = (char**) malloc(prmTamanioApuntador*sizeof(char*));

	for(int i = 0; i < prmTamanioApuntador; i++)
		ptrApuntador[i] = (char*) calloc(prmTamanioApuntadorCadena, sizeof(char));

	return ptrApuntador;
}

char **dimensionarApuntadorDeApuntadorCadenaSinApuntadores(int prmTamanioApuntador)
{
	return (char **) calloc(prmTamanioApuntador, sizeof(char *));
}

void liberarDimensionApuntadorCadena(char *prmApuntador)
{
	free(prmApuntador);
}

void liberarDimensionApuntadorDeApuntadorCadena(char **prmApuntador, int prmTamanioApuntador)
{
	for(int i = 0; i < prmTamanioApuntador; i++)
		free(prmApuntador[i]);

	free(prmApuntador);
}

int obtenerTamanioCadena(char *prmCadena)
{
	int varBandera = 1, varIterador = 0;

	while(varBandera){
		
		if(prmCadena[varIterador])
			varIterador++;
		else
			varBandera = 0;
	}

	return varIterador;
}

void limpiarCadenaDeApuntador(char* prmCadena)
{
	int varTamanio = obtenerTamanioCadena(prmCadena);

	for(int i = 0; i < varTamanio; i++)
		prmCadena[i] = 0;
}

void depurarCadenaDeApuntador(char *prmCadena)
{
	int varTamanio = obtenerTamanioCadena(prmCadena);

	for(int i = 0; i < varTamanio; i++){

		if(!((prmCadena[i] >= 32) && (prmCadena[i] <= 126)))
			prmCadena[i] = 0;
	}
}

void concatenarCadenaConCaracter(char *prmCadena, char prmCaracter, char *prmCadenaNueva)
{
	int varTamanio = obtenerTamanioCadena(prmCadena);

	for(int i = 0; i < varTamanio; i++)
		prmCadenaNueva[i] = prmCadena[i];

	prmCadenaNueva[varTamanio] = prmCaracter;
}

void concatenarCadenas(char *prmCadena1, char* prmCadena2, char *prmCadenaNueva)
{
	int varTamanio1 = obtenerTamanioCadena(prmCadena1),
		varTamanio2 = obtenerTamanioCadena(prmCadena2),
		varBandera = 1,
		varRepetir = 1,
		varIterador = 0;

	while(varBandera){

		if((varRepetir) && (varIterador < varTamanio1)){

			prmCadenaNueva[varIterador] = prmCadena1[varIterador];

			if(varIterador == varTamanio1-1){
				varIterador = -1;
				varRepetir = 0;
			}
		}
		else if(varIterador < varTamanio2){

			prmCadenaNueva[varTamanio1+varIterador] = prmCadena2[varIterador];
		}
		else
			varBandera = 0;

		varIterador++;
	}
}

void repetirCaracter(char *prmCadena, char prmCaracter, int *prmN)
{
	for(int i = 0; i < *prmN; i++)
		prmCadena[i] = prmCaracter;
}

int validarCadenasIguales(char *prmCadena1, char *prmCadena2)
{
	int varTamanioCadena1 = obtenerTamanioCadena(prmCadena1),
		varTamanioCadena2 = obtenerTamanioCadena(prmCadena2);

	if(varTamanioCadena1 == varTamanioCadena2){

		int varIterador = 0;

		while(varIterador < varTamanioCadena1){

			if(prmCadena1[varIterador] != prmCadena2[varIterador])
				return 0;
			varIterador++;
		}
		return 1;
	}
	return 0;
}

void eliminarCaracterDeCadena(char *prmCadena, char prmCaracter, char *prmNuevaCadena)
{
	int varTamanio = obtenerTamanioCadena(prmCadena);
	int varIteradorCadena = 0, varIteradorNuevaCadena = 0;

	while(varIteradorNuevaCadena < varTamanio){

		if(prmCadena[varIteradorCadena] != prmCaracter){
			prmNuevaCadena[varIteradorNuevaCadena] = prmCadena[varIteradorCadena];
			
			varIteradorNuevaCadena++;
		}
		varIteradorCadena++;	
	}
}

void extraerSubCadenaDeCadena(char *prmCadena, int prmIndice, char *prmNuevaCadena)
{
	int varTamanio = obtenerTamanioCadena(prmCadena) - 1;

	for(int i = 0; i <= (varTamanio - prmIndice); i++)
		prmNuevaCadena[i] = prmCadena[i + prmIndice];
}

void extraerSubCadenaDinamicaDeCadena(char *prmCadena, int prmIndiceInicial, int prmIndiceFinal, char *prmNuevaCadena)
{
	for(int i = 0; i <= (prmIndiceFinal - prmIndiceInicial); i++)
		prmNuevaCadena[i] = prmCadena[i + prmIndiceInicial];
}

void eliminarSubCadenaDeCadena(char *prmCadena, char *prmSubCadena, char *prmNuevaCadena)
{
	int varTamanioCadena = obtenerTamanioCadena(prmCadena),
		varTamanioSubCadena = obtenerTamanioCadena(prmSubCadena);

	char *ptrSubCadenaTemporal = dimensionarApuntadorCadena(255);

	int varIteradorCadena = 0, varIteradorNuevaCadena = 0;

	while(varIteradorNuevaCadena < varTamanioCadena){
				
		if(prmCadena[varIteradorCadena] == prmSubCadena[0]){

			extraerSubCadenaDinamicaDeCadena(prmCadena, varIteradorCadena, varIteradorCadena + (varTamanioSubCadena - 1), ptrSubCadenaTemporal);
			
			if(validarCadenasIguales(ptrSubCadenaTemporal, prmSubCadena)){
				limpiarCadenaDeApuntador(ptrSubCadenaTemporal);
				varIteradorCadena += (varTamanioSubCadena);
			}
		}
		
		prmNuevaCadena[varIteradorNuevaCadena] = prmCadena[varIteradorCadena];
		varIteradorNuevaCadena++;
		varIteradorCadena++;	
	}
	liberarDimensionApuntadorCadena(ptrSubCadenaTemporal);
}

int encontrarIndiceCaracterDeCadena(char *prmCadena, char prmCaracter)
{
	int varTamanio = obtenerTamanioCadena(prmCadena);

	for(int i = 0; i < varTamanio; i++){

		if(prmCadena[i] == prmCaracter)
			return i;
	}
	return -1;
}

int* encontrarIndicesDeCaracterDeCadena(char *prmCadena, char prmCaracter)
{
	int varTamanio = obtenerTamanioCadena(prmCadena),
		*ptrArreglo = dimensionarArregloEntero(varTamanio), varIterador = 0;

	for(int i = 0; i < varTamanio; i++){

		if(prmCadena[i] == prmCaracter){
			ptrArreglo[varIterador] = i;
			varIterador++;
		}
	}
	
	if(varIterador > 0)
		return ptrArreglo;
	return ptrArreglo;
}

int contarCaracterRepetidoDeCadena(char *prmCadena, char prmCaracter)
{
	int varTamanio = obtenerTamanioCadena(prmCadena),
		varContador = 0;

	for(int i = 0; i < varTamanio; i++){

		if(prmCadena[i] == prmCaracter)
			varContador++;
	}
	return varContador;
}

void recortarCadena(char *prmCadena, int prmIndice, char *prmNuevaCadena)
{
	for(int i = 0; i <= prmIndice; i ++)
		prmNuevaCadena[i] = prmCadena[i];
}

void clonarCadena(char *prmCadena, char *prmCadenaClonada)
{
	int varTamnio = obtenerTamanioCadena(prmCadena);

	for(int i = 0; i < varTamnio; i++)
		prmCadenaClonada[i] = prmCadena[i];
}

void reemplazarCaracteresDeEspacioDeCadena(char *prmCadena, char prmCaracterDeReemplazo)
{
	int varTamanio = obtenerTamanioCadena(prmCadena);

	for(int i = 0; i < varTamanio; i++){

		if(prmCadena[i] == ' ')
			prmCadena[i] = prmCaracterDeReemplazo;
	}
}

void reemplazarCaracterDeCadena(char *prmCadena, int prmIndice, char prmCaracter)
{
	prmCadena[prmIndice] = prmCaracter;
}
