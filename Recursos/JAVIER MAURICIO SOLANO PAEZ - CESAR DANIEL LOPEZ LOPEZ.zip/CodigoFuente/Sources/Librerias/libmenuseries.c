#include "../../Headers/libmenuseries.h"

/**
* @brief variable goblal que controla la salida del menu series.
**/ 
int glbSalidaMenuSeries;

void imprimirMenuSeries()
{
    // Cantidad de items de opciones que tendra el menu.
    int varCantItemsMenu = 5, varOpcion = 0;

    // Apuntador de apuntadores de los items del menu.
    char **ptrMenu = definirMenu(varCantItemsMenu);
    establecerTituloMenu(ptrMenu, "MENU SERIES");

    // Establecemos las opciones del menu.
    aniadirItemMenu(ptrMenu, ++varOpcion, "Fibonacci.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Primos.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Pares.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Impares");

    // Asignamos la opcion que corresponde a la salida del menu.
    aniadirItemMenu(ptrMenu, ++varOpcion, "Salir del menu.");
    glbSalidaMenuSeries = varOpcion;
    
    imprimirMenu(ptrMenu, varCantItemsMenu);
    liberarMenu(ptrMenu, varCantItemsMenu); // Liberamos el espacio en memoria del menu.
}
