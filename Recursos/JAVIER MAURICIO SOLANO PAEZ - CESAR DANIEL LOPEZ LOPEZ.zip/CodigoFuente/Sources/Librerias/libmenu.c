#include "../../Headers/libmenu.h"
#include "./libentradaysalida.c"

char** definirMenu(int prmCantItems)
{
   return  dimensionarApuntadorDeApuntadorCadena(1 + prmCantItems, 255);
}

void establecerTituloMenu(char **prmMenu, char *prmTitulo)
{
    prmMenu[0] = prmTitulo;
}

void aniadirItemMenu(char **prmMenu, int prmOpcion, char *prmItem)
{
    prmMenu[prmOpcion] = prmItem;
}

void imprimirMenu(char **prmMenu, int prmCantOpciones)
{
    imprimirCadena("\t");
    imprimirCadenaConSalto(prmMenu[0]);

    for(int i = 1; i <= prmCantOpciones; i++){
        imprimirNumeroEntero(i);
        imprimirCadena(". ");
        imprimirCadenaConSalto(prmMenu[i]);
    }
}

void liberarMenu(char **prmApuntador, int prmCantItems)
{
    liberarDimensionApuntadorDeApuntadorCadena(prmApuntador, prmCantItems + 1);
}
