#include "../../Headers/libaritmetica.h"
#include <math.h>

void imprimirResultadoAritmetico(double *prmResultado)
{
    imprimirCaracterConSalto(' ');

    if((*prmResultado - trunc(*prmResultado)) != 0){
        
        imprimirCadenaConNumeroDouble("Resultado: ", *prmResultado);
        imprimirCadena(" aproximadamente.");

    }else
        imprimirCadenaConNumeroEntero("Resultado: ", (int)*prmResultado);
}

void sumar(double *prmNumero1, double *prmNumero2)
{
    double varSuma = *prmNumero1 + *prmNumero2;   
    imprimirResultadoAritmetico(&varSuma);
}

void restar(double *prmNumero1, double *prmNumero2)
{
    double varResta = *prmNumero1 - *prmNumero2; 
    imprimirResultadoAritmetico(&varResta);
}

void multiplicar(double *prmNumero1, double *prmNumero2)
{
    double varProducto = *prmNumero1 * (*prmNumero2);    
    imprimirResultadoAritmetico(&varProducto);
}

void dividir(double *prmNumero1, double *prmNumero2)
{
    double varCociente = *prmNumero1 / (*prmNumero2); 
    imprimirResultadoAritmetico(&varCociente);
}
