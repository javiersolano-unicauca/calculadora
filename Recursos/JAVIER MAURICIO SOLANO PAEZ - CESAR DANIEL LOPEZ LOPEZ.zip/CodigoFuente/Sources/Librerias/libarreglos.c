#include "../../Headers/libarreglos.h"
#include <stdlib.h>
#include <math.h>

double* dimensionarArregloDeTipoDouble(int *prmTamanio)
{
    return (double*) calloc(*prmTamanio, sizeof(double));
}

void liberarArregloDeTipoDouble(double *prmArreglo)
{
    free(prmArreglo);
}

void llenarArregloDeTipoDouble(double *prmArreglo, int *prmTamanio)
{
    imprimirCaracterConSalto(' ');
    imprimirCadenaConSalto("A continuacion, ingrese los elementos que va contener el arreglo:");
    imprimirCaracterConSalto(' ');

    for(int i = 0; i < *prmTamanio; i++){

        imprimirCadenaConNumeroEntero("Elemento ", i+1);
        recibirDatoDouble("", &prmArreglo[i]);
    }
}

void imprimirArregloDeTipoDouble(double *prmArreglo, int *prmTamanio)
{
    imprimirCaracterConSalto(' ');
    imprimirCadenaConSalto("Arreglo obtenido:");
    imprimirCaracterConSalto(' ');

    imprimirCaracter('[');

    for(int i = 0; i < *prmTamanio; i++){

        if((prmArreglo[i] - trunc(prmArreglo[i])) != 0)
            imprimirNumeroDouble(prmArreglo[i]);
        else
            imprimirNumeroEntero(prmArreglo[i]);

        if(i < *prmTamanio-1)
            imprimirCadena(", ");
    }

    imprimirCaracterConSalto(']');
}

void imprimirResultadoArreglo(double *prmResultado)
{
    imprimirCaracterConSalto(' ');

    if((*prmResultado - trunc(*prmResultado)) != 0){
        
        imprimirCadenaConNumeroDouble("Resultado: ", *prmResultado);
        imprimirCadena(" aproximadamente.");

    }else
        imprimirCadenaConNumeroEntero("Resultado: ", (int)*prmResultado);
}

void recibirElementosDeArregloDeTipoDouble(double *prmArreglo, int *prmTamanio)
{
    llenarArregloDeTipoDouble(prmArreglo, prmTamanio);
    imprimirArregloDeTipoDouble(prmArreglo, prmTamanio);
}

void sumarElementosDeArregloDeTipoDouble(int *prmTamanio)
{
    double *ptrArreglo = dimensionarArregloDeTipoDouble(prmTamanio);
    recibirElementosDeArregloDeTipoDouble(ptrArreglo, prmTamanio);

    imprimirMensaje("Sumando elementos...");

    double varSuma = ptrArreglo[0];

    for(int i = 1; i < *prmTamanio; i++)
        varSuma += ptrArreglo[i];

    esperarLectura();

    imprimirResultadoArreglo(&varSuma);
    liberarArregloDeTipoDouble(ptrArreglo); // Liberamos el espacio en memoria del arreglo.
}

void restarElementosDeArregloDeTipoDouble(int *prmTamanio)
{
    double *ptrArreglo = dimensionarArregloDeTipoDouble(prmTamanio);
    recibirElementosDeArregloDeTipoDouble(ptrArreglo, prmTamanio);

    imprimirMensaje("Restando elementos...");

    double varResta = ptrArreglo[0];

    for(int i = 1; i < *prmTamanio; i++)
        varResta -= ptrArreglo[i];

    esperarLectura();

    imprimirResultadoArreglo(&varResta);
    liberarArregloDeTipoDouble(ptrArreglo); // Liberamos el espacio en memoria del arreglo.
}

void multiplicarElementosDeArregloDeTipoDouble(int *prmTamanio)
{
    double *ptrArreglo = dimensionarArregloDeTipoDouble(prmTamanio);
    recibirElementosDeArregloDeTipoDouble(ptrArreglo, prmTamanio);

    imprimirMensaje("Multiplicando elementos...");

    double varProducto = ptrArreglo[0];

    for(int i = 1; i < *prmTamanio; i++)
        varProducto *= (ptrArreglo[i]);

    esperarLectura();

    imprimirResultadoArreglo(&varProducto);
    liberarArregloDeTipoDouble(ptrArreglo); // Liberamos el espacio en memoria del arreglo.
}

void dividirElementosDeArregloDeTipoDouble(int *prmTamanio)
{
    double *ptrArreglo = dimensionarArregloDeTipoDouble(prmTamanio);
    recibirElementosDeArregloDeTipoDouble(ptrArreglo, prmTamanio);

    imprimirMensaje("Dividiendo elementos...");

    double varCociente = ptrArreglo[0];

    for(int i = 1; i < *prmTamanio; i++)
        varCociente /= ptrArreglo[i];

    esperarLectura();

    imprimirResultadoArreglo(&varCociente);
    liberarArregloDeTipoDouble(ptrArreglo); // Liberamos el espacio en memoria del arreglo.
}

void ordenarElementosDeArregloDeTipoDouble(int *prmTamanio){

    double *ptrArreglo = dimensionarArregloDeTipoDouble(prmTamanio);
    recibirElementosDeArregloDeTipoDouble(ptrArreglo, prmTamanio);

    imprimirMensaje("Ordenando elementos...");
    esperarLectura();

	double varSiguiente; int varRepetir;
	
	for(int i = 0; i < *prmTamanio; i++){
		
		if(((i+1) < *prmTamanio) && (ptrArreglo[i] > ptrArreglo[i+1])){
            
			varSiguiente = ptrArreglo[i+1];
			ptrArreglo[i+1] = ptrArreglo[i];
			ptrArreglo[i] = varSiguiente;

			varRepetir = 1;
		}
		
		if((i == (*prmTamanio-1)) && (varRepetir)){
			i = -1;
			varRepetir = 0;
		}
	}

    imprimirArregloDeTipoDouble(ptrArreglo, prmTamanio);
    liberarArregloDeTipoDouble(ptrArreglo); // Liberamos el espacio en memoria del arreglo.
}

void reversarElementosDeArregloDeTipoDouble(int *prmTamanio)
{
    double *ptrArreglo = dimensionarArregloDeTipoDouble(prmTamanio);
    recibirElementosDeArregloDeTipoDouble(ptrArreglo, prmTamanio);

    imprimirMensaje("Reversando elementos...");
    esperarLectura();

    imprimirMensaje("RESULTADO:");
    imprimirCaracter('[');

    for(int i = *prmTamanio-1; i >= 0; i--){

        if((ptrArreglo[i] - trunc(ptrArreglo[i])) != 0)
            imprimirNumeroDouble(ptrArreglo[i]);
        else
            imprimirNumeroEntero(ptrArreglo[i]);

        if(i > 0)
            imprimirCadena(", ");
    }

    imprimirCaracterConSalto(']');
    liberarArregloDeTipoDouble(ptrArreglo); // Liberamos el espacio en memoria del arreglo.
}

void multiplicarElementosDeArregloDeTipoDoublePorEscalar(int *prmTamanio)
{
    int varEscalar;
    recibirDatoEntero("Ingrese el escalar de tipo entero", &varEscalar);
    imprimirCaracterConSalto(' ');

    double *ptrArreglo = dimensionarArregloDeTipoDouble(prmTamanio);
    recibirElementosDeArregloDeTipoDouble(ptrArreglo, prmTamanio);

    imprimirMensaje("Multiplicando escalar por elementos...");
    esperarLectura();

    double *ptrArregloResultante = dimensionarArregloDeTipoDouble(prmTamanio);

    for(int i = 0; i < *prmTamanio; i++)
        ptrArregloResultante[i] = varEscalar * ptrArreglo[i];

    imprimirArregloDeTipoDouble(ptrArregloResultante, prmTamanio);

    // Liberamos el espacio en memoria de los arreglos.
    liberarArregloDeTipoDouble(ptrArreglo);
    liberarArregloDeTipoDouble(ptrArregloResultante);
}
