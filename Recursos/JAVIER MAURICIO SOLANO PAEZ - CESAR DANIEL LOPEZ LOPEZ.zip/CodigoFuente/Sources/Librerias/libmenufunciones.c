#include "../../Headers/libmenufunciones.h"

/**
* @brief variable goblal que controla la salida del menu de funciones especiales.
**/
int glbSalidaMenuFunciones;

void imprimirMenuFunciones()
{
    // Cantidad de items de opciones que tendra el menu.
    int varCantItemsMenu = 3, varOpcion = 0;

    // Apuntador de apuntadores de los items del menu.
    char **ptrMenu = definirMenu(varCantItemsMenu);
    establecerTituloMenu(ptrMenu, "MENU FUNCIONES ESPECIALES");

    // Establecemos las opciones del menu.
    aniadirItemMenu(ptrMenu, ++varOpcion, "Factorial.");
    aniadirItemMenu(ptrMenu, ++varOpcion, "Potencia.");

    // Asignamos la opcion que corresponde a la salida del menu.
    aniadirItemMenu(ptrMenu, ++varOpcion, "Salir del menu.");
    glbSalidaMenuFunciones = varOpcion;
    
    imprimirMenu(ptrMenu, varCantItemsMenu);
    liberarMenu(ptrMenu, varCantItemsMenu); // Liberamos el espacio en memoria del menu.
}
