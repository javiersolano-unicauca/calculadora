#include "../../Headers/libgraficas.h"

void imprimirCuadrado()
{
    int varLongitudLado;

    recibirDatoEntero("Ingrese la longitud de tipo entero del lado del cuadrado", &varLongitudLado);
    imprimirCaracterConSalto(' ');

    int varIterador = 1, varContadorFilas = 1;

    while(varContadorFilas <= varLongitudLado){

        if(varIterador <= varLongitudLado){

            imprimirCaracter(' ');
            
            if(varIterador < varLongitudLado)
                imprimirCaracter('*');
            else
                imprimirCaracterConSalto('*');

            varIterador++;

        }else{
            varIterador = 1;
            varContadorFilas++;
        }
    }
}

void imprimirRectangulo()
{
    int varLongitudBase, varLongitudAltura;

    recibirDatoEntero("Ingrese la longitud de tipo entero de la base del rectangulo", &varLongitudBase);
    recibirDatoEntero("Ingrese la longitud de tipo entero de la altura del rectangulo", &varLongitudAltura);
    imprimirCaracterConSalto(' ');

    int varIterador = 1, varContadorFilas = 1;

    while(varContadorFilas <= varLongitudAltura){

        if(varIterador <= varLongitudBase){

            imprimirCaracter(' ');
            
            if(varIterador < varLongitudBase)
                imprimirCaracter('*');
            else
                imprimirCaracterConSalto('*');

            varIterador++;

        }else{
            varIterador = 1;
            varContadorFilas++;
        }
    }
}

void imprimirTriangulo()
{
    int varLongitudBase;

    recibirDatoEntero("Ingrese la longitud de tipo entero de la base del triangulo equilatero", &varLongitudBase);
    imprimirCaracterConSalto(' ');

    int varIterador = 0, varContadorFilas = 1;

    while(varContadorFilas <= varLongitudBase){

        if(varIterador <= varLongitudBase){

            if(varIterador <= (varLongitudBase - varContadorFilas))
                imprimirCaracter(' ');
            
            else if(varIterador < varLongitudBase)
                imprimirCadena("* "); 

            else 
                imprimirCaracterConSalto('*');

            varIterador++;
            
        }else{
            varIterador = 0;
            varContadorFilas++;
        }
    }
}

void imprimirTrapecioIsoscelesSinEntradaConsola(int *prmBaseMenor)
{
    int varFila = 0, varIterador = 0, varBaseMenor = *prmBaseMenor - 1;

    while(varFila <= varBaseMenor){

        if(varIterador < (varBaseMenor - varFila))
            imprimirCaracter(' ');

        else if(varIterador < ((varBaseMenor - varFila) + (varBaseMenor + varFila)))
            imprimirCadena(" *");

        else{
            imprimirCadenaConSalto(" *");
            varIterador = -1;
            varFila++;
        }

        varIterador++;
    }
}

void imprimirArbolSencillo()
{
    int varAltura, varIterador = 0, varContadorFilas = 1;

    recibirDatoEntero("Ingrese la altura que debe tener el arbol. No debe ser superior a 44", &varAltura);  imprimirCaracterConSalto(' ');

    if(varAltura <= 44){

        imprimirCaracterJustificado(varAltura+2, '*');

        while(varContadorFilas < varAltura){

            if(varIterador <= (varAltura + (varContadorFilas + 1))){

                if(varIterador <= (varAltura - varContadorFilas))
                    imprimirCaracter(' ');
                
                else if(varIterador < (varAltura + (varContadorFilas + 1)))
                    imprimirCaracterEspecial('°');

                else 
                    imprimirCaracterEspecialConSalto('°');

                varIterador++;
                
            }else{
                varIterador = 0;
                varContadorFilas++;
            }
        }

        imprimirCadenaJustificada(varAltura+1, "| |");
    }else
        imprimirCadenaConSalto("La altura supera la permitida.");
}

imprimirArbolCompuesto()
{
    int varAltura, varIterador = 0, varContadorFilas = 1;

    recibirDatoEntero("Ingrese la altura que debe tener el arbol", &varAltura);  imprimirCaracterConSalto(' ');

    imprimirCaracterJustificado(varAltura+3, '*');

    while(varContadorFilas < varAltura){

        if(varIterador <= (varAltura + (varContadorFilas + 1))){

            if(varIterador < (varAltura - (varContadorFilas - 1)))
                imprimirCaracter(' ');

            else if(varIterador == (varAltura - (varContadorFilas - 1))){
                 imprimirCaracterEspecial('°'); imprimirCaracter('+'); 
            }

            else if(varIterador == (varAltura + 1))
                imprimirCaracterEspecial('°');
            
            else if(varIterador < (varAltura + (varContadorFilas + 1)))
                imprimirCaracter('+');

            else{
                imprimirCaracter('+'); imprimirCaracterEspecialConSalto('°');    
            }

            varIterador++;
            
        }else{
            varIterador = 0;
            varContadorFilas++;
        }
    }

    imprimirCadenaJustificada(varAltura+2, "| |");
}

void imprimirArbolNumerico()
{
    int varAltura, varIterador = 0, varContadorFilas = 1;

    recibirDatoEntero("Ingrese la altura que debe tener el arbol", &varAltura);  imprimirCaracterConSalto(' ');

    imprimirCaracterJustificado(varAltura+2, '1');

        while(varContadorFilas < varAltura){

            if(varIterador <= (varAltura + varContadorFilas + 1)){

                if(varIterador <= (varAltura - varContadorFilas))
                    imprimirCaracter(' ');
                
                else if(varIterador < (varAltura + varContadorFilas + 1))
                    imprimirNumeroEntero(varIterador - (varAltura - varContadorFilas));

                else{
                    imprimirNumeroEntero(varIterador - (varAltura - varContadorFilas)); imprimirCaracterConSalto(' ');
                }

                varIterador++;
                
            }else{
                varIterador = 0;
                varContadorFilas++;
            }
        }
}

void imprimirArbolNumericoConSeparador()
{
    int varAltura, varIterador = 0, varContadorFilas = 1;

    recibirDatoEntero("Ingrese la altura que debe tener el arbol", &varAltura);  imprimirCaracterConSalto(' ');

    imprimirCaracterJustificado(varAltura+2, '1');

        while(varContadorFilas < varAltura){

            if(varIterador <= (varAltura + varContadorFilas + 1)){

                if(varIterador <= (varAltura - varContadorFilas))
                    imprimirCaracter(' ');
                
                else if(varIterador < (varAltura + varContadorFilas + 1)){
                    imprimirNumeroEntero(varIterador - (varAltura - varContadorFilas)); imprimirCaracter('-');
                }

                else{
                    imprimirNumeroEntero(varIterador - (varAltura - varContadorFilas)); imprimirCaracterConSalto(' ');
                }

                varIterador++;
                
            }else{
                varIterador = 0;
                varContadorFilas++;
            }
        }
}