#include "../../Headers/libmatrices.h"
#include <stdlib.h>

int** dimensionarMatrizDeTipoEntero(int *prmM, int *prmN)
{
    int **matriz = (int**) malloc(*prmM*sizeof(int*));

    for(int i = 0;  i < *prmM; i++)
        matriz[i] = (int*) calloc(*prmN, sizeof(int));

    return matriz;
}

void liberarDimensionMatrizDeTipoEntero(int **prmMatriz, int *prmM)
{
    for(int i = 0; i < *prmM; i++)
        free(prmMatriz[i]);

    free(prmMatriz);
}

void llenarMatriz(int **prmMatriz, int *prmM, int *prmN)
{
    int varFila = 0, varColumna = 0;

    imprimirMensaje("A continuacion, ingrese los numeros que va contener la matriz:");

    while(varFila < *prmM){

        if(varColumna < *prmN){

            imprimirCadenaConNumeroEntero("Fila ", varFila+1);
            imprimirCadenaConNumeroEntero(" - Columna ", varColumna+1);
            recibirDatoEntero("", &prmMatriz[varFila][varColumna]);

            varColumna++;

        }else{
            imprimirCaracterConSalto(' ');
            varColumna = 0;
            varFila++;
        }
    }
}

void imprimirMatriz(int **prmMatriz, int *prmM, int *prmN)
{
    imprimirMensaje("Matriz obtenida:");

    int varFila = 0, varColumna = 0;

    while(varFila < *prmM){

        if(varColumna == 0)
            imprimirCaracter('|');
        
        if(varColumna < *prmN){

            if((prmMatriz[varFila][varColumna] >= 0) && (prmMatriz[varFila][varColumna] < 10))
                imprimirCadenaConNumeroEntero("  ", prmMatriz[varFila][varColumna]);
            else
                imprimirCadenaConNumeroEntero(" ", prmMatriz[varFila][varColumna]);
            
            varColumna++;

        }else{
            imprimirCadenaConSalto(" |");
            varColumna = 0;
            varFila++;
        }
    }
}

void recibirElementosDeMatrizDeTipoEntero(int **prmMatriz, int *prmM, int *prmN)
{
    llenarMatriz(prmMatriz, prmM, prmN);
    imprimirMatriz(prmMatriz, prmM, prmN);
}

void sumarMatricesDeTipoEntero()
{
    int varM, varN;

    recibirDatoEntero("Ingrese la cantidad de filas que va tener cada matriz de tipo entero", &varM);
    recibirDatoEntero("Ingrese la cantidad de columnas que va tener cada matriz de tipo entero", &varN);

    int **pA = dimensionarMatrizDeTipoEntero(&varM, &varN),
        **pB = dimensionarMatrizDeTipoEntero(&varM, &varN);

    imprimirMensaje("Matriz (A):");
    recibirElementosDeMatrizDeTipoEntero(pA, &varM, &varN);

    imprimirMensaje("Matriz (B):");
    recibirElementosDeMatrizDeTipoEntero(pB, &varM, &varN);

    imprimirMensaje("Sumando matrices...");

    int varFila = 0, varColumna = 0, **pC = dimensionarMatrizDeTipoEntero(&varM, &varN);

    while(varFila < varM){

        if(varColumna < varN){

            pC[varFila][varColumna] = pA[varFila][varColumna] + pB[varFila][varColumna];
            varColumna++;

        }else{
            varColumna = 0;
            varFila++;
        }
    }

    esperarLectura();
    imprimirMensaje("RESULTADO:");
    imprimirMatriz(pC, &varM, &varN);

    // Liberamos el espacio reservado en memoria.
    liberarDimensionMatrizDeTipoEntero(pA, &varM);
    liberarDimensionMatrizDeTipoEntero(pB, &varM);
    liberarDimensionMatrizDeTipoEntero(pC, &varM);
}

void multiplicarMatricesDeTipoEntero()
{
    int varAM, varAN, varBM, varBN;

    recibirDatoEntero("Ingrese la cantidad de filas que va tener la matriz de tipo entero (A)", &varAM);
    recibirDatoEntero("Ingrese la cantidad de columnas que va tener la matriz de tipo entero (A)", &varAN);
    imprimirCaracterConSalto(' ');
    recibirDatoEntero("Ingrese la cantidad de filas que va tener la matriz de tipo entero (B)", &varBM);
    recibirDatoEntero("Ingrese la cantidad de columnas que va tener la matriz de tipo entero (B)", &varBN);
    
    if(varAN == varBM){

        int **pA = dimensionarMatrizDeTipoEntero(&varAM, &varAN),
            **pB = dimensionarMatrizDeTipoEntero(&varBM, &varBN);

        imprimirMensaje("Matriz (A):");
        recibirElementosDeMatrizDeTipoEntero(pA, &varAM, &varAN);

        imprimirMensaje("Matriz (B):");
        recibirElementosDeMatrizDeTipoEntero(pB, &varBM, &varBN);

        imprimirMensaje("Multiplicando matrices...");

        int varFila = 0, varColumna = 0, varAux = 0, **pC = dimensionarMatrizDeTipoEntero(&varAM, &varBN);

        while(varFila < varAM){

            if(varColumna < varAN){

                pC[varFila][varAux] += pA[varFila][varColumna] * pB[varColumna][varAux];
                varColumna++;

            }else if(varAux < varBN-1){

                varColumna = 0;
                varAux++;
    
            }else{
                varColumna = 0;
                varAux = 0;
                varFila++;
            }
        }

        esperarLectura();
        imprimirMensaje("RESULTADO:");
        imprimirMatriz(pC, &varAM, &varBN);

        // Liberamos el espacio reservado en memoria.
        liberarDimensionMatrizDeTipoEntero(pA, &varAM);
        liberarDimensionMatrizDeTipoEntero(pB, &varBM);
        liberarDimensionMatrizDeTipoEntero(pC, &varAM);

    }else{
        imprimirMensaje("No se puede realizar la operacion...");
        imprimirMensaje("Recuerde que la cantidad de columnas de la matriz (A) debe ser la misma que la de filas de (B).");
    }
}

void multiplicarEscalarTipoEnteroPorMatrizTipoEntero()
{
    int varEscalar;
    recibirDatoEntero("Ingrese el escalar de tipo entero", &varEscalar);
    imprimirCaracterConSalto(' ');

    int varM, varN;
    recibirDatoEntero("Ingrese la cantidad de filas que va tener la matriz de tipo entero", &varM);
    recibirDatoEntero("Ingrese la cantidad de columnas que va tener la matriz de tipo entero", &varN);
    
    int **pA = dimensionarMatrizDeTipoEntero(&varM, &varN);
    recibirElementosDeMatrizDeTipoEntero(pA, &varM, &varN);

    imprimirMensaje("Multiplicando escalar por matriz...");

    int varFila = 0, varColumna = 0, **pB = dimensionarMatrizDeTipoEntero(&varM, &varN);

    while(varFila < varM){

        if(varColumna < varN){

            pB[varFila][varColumna] = varEscalar * pA[varFila][varColumna];
            varColumna++;

        }else{
            varColumna = 0;
            varFila++;
        }
    }

    esperarLectura();
    imprimirMensaje("RESULTADO:");
    imprimirMatriz(pB, &varM, &varN);

    // Liberamos el espacio reservado en memoria.
    liberarDimensionMatrizDeTipoEntero(pA, &varM);
    liberarDimensionMatrizDeTipoEntero(pB, &varM);
}